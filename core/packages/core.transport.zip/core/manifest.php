<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bec67fa2b3eff9ff931c3fb32157fee0',
      'native_key' => 'core',
      'filename' => 'modNamespace/9d12432497b19cde4a66f514904b59a2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '8f54f1b638289c3cd99cafb5bbd2e3f3',
      'native_key' => 1,
      'filename' => 'modWorkspace/91cd9a5b3a231126133cc32644a1c3c6.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '7eb6a7bcffe4dd3e72034ff5c818e84c',
      'native_key' => 1,
      'filename' => 'modTransportProvider/16de4155dd732f8b43fb1bb2666ca33c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '526144160e976b5959b55a203c758128',
      'native_key' => 'topnav',
      'filename' => 'modMenu/23099e0845d8a0573ac1c807aee631ea.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'dc394f77121c2fdcc8a0cf1a0822bd0c',
      'native_key' => 'usernav',
      'filename' => 'modMenu/a8819fd0fbd429f8e5fb76727ee0e5db.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a35dcaef4f019453c15e9b543b6198ed',
      'native_key' => 1,
      'filename' => 'modContentType/925b9f6e8f1d375f5905dbd9cb34c8dc.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fbcd5f8fd2a305991f520684c6b0cb77',
      'native_key' => 2,
      'filename' => 'modContentType/452fc015c12db814ef49821e8c2ede2e.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f27b524d41c0f462ec49f9507079793f',
      'native_key' => 3,
      'filename' => 'modContentType/f12e03ec72fb8a0cdaa2acae0fbcff56.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '61a979ccac983180f03b7cd6e50a41fc',
      'native_key' => 4,
      'filename' => 'modContentType/576cc4a237a771d67a56d97ef742ef6d.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'c49ffda1666561b52a3bd0f181c8ca30',
      'native_key' => 5,
      'filename' => 'modContentType/c78df0c3b6b5b239d8c24aeedf7ece48.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '37e1c9913bad886f9df3f9a45bf66464',
      'native_key' => 6,
      'filename' => 'modContentType/3c3832972e29043251bcf802a15c2e3c.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '529bca30a652ab7de6a1f2764615d233',
      'native_key' => 7,
      'filename' => 'modContentType/278a6294de465b9240daaa4748aed83c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '54990b5dd6ad6c0f910850a68efd818a',
      'native_key' => 8,
      'filename' => 'modContentType/5e10d71115d8567d0242f0a1686afa4a.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2f0bf5a5623dd009596e8284d956b755',
      'native_key' => NULL,
      'filename' => 'modClassMap/5f20aa8bacf865f27b7d999c61b97dd0.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9a362f0060868494323205176c19fa5c',
      'native_key' => NULL,
      'filename' => 'modClassMap/6dd82ddb6218faa23b2f10bfabff9edb.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'bd7223317b6aa171e9a66aa4b4c0e456',
      'native_key' => NULL,
      'filename' => 'modClassMap/6239e94fc09b0a09924b23f7db5a509c.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ad0017920227ba5568f46bad6b9bf14b',
      'native_key' => NULL,
      'filename' => 'modClassMap/02c16babd8344a8f4dd9392f4e3c6033.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4640eda25b38008ec8c8ecb0b452bfe7',
      'native_key' => NULL,
      'filename' => 'modClassMap/23df96266c447269b7353a795b8162d9.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'e1f36ed696ad5ac32cf594eb03615a92',
      'native_key' => NULL,
      'filename' => 'modClassMap/e5dbe205c0cc665a5464f0e22a5a2d24.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '140fe52a53710acd9950d4b18414cbe8',
      'native_key' => NULL,
      'filename' => 'modClassMap/acbb73dbd7a4d40a85e2a8ab31901c89.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '4b15daa5f90bc89503ec75238aa50531',
      'native_key' => NULL,
      'filename' => 'modClassMap/4773079559ccd1af17a0dbb1ebe54a5a.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '42e340acda709368a5f74ad17930ae4b',
      'native_key' => NULL,
      'filename' => 'modClassMap/84e41a5884cc4ecdc9abed0f4d7c93f5.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c52c720f8895a6f5daa16c1160ef14e5',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/35cf447157992a8e176190297d37e9fc.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0043d41ba22612ced745efaee2f83f6e',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/759f297df4fc28ad4fd72b3168cdbf59.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17ac4106d7ffd890e0874889ec9a99c4',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/247fbfb84b9475a1cb64b06b5757bbcc.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8738c4bcb680017111d2083b6f7489b4',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/39e88ab91331ffece6f27a5514092403.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f2e2641c878373aec18eb9f8f36a921',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/6a7083c99b4c99f7da2cbb9a280d9617.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '528f868c7d9f01b852f30b922484f917',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/a299be988a4fe5d804cf438e471cddaf.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '188fd6bc324876c20edc41bd40c46972',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/df5ab8efb10eeeea92d0f0ea3c511b27.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2087ea4434644a1fdd8e80a16f3bf22',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/9cce5a7bb7234d817f4498d22f0fb465.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36bd07513f60503a1af11d09b549ad0b',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/855a4f232c2640482c439b558aa90ab6.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f357483d6a4a33967c45af15956c1503',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/64a421bcbc10b3c41ffd990333ad1c41.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddf215465cd248eb866dcc570204db75',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/4e3021c03cc118a5423cfccf27ecc682.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c5532457f4eb6393bbbf0c4c33c4504',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/fda96647f8f2a770c52ec844c80935ce.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c33f94fde299ca5c9c120a2758bbb96',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/6524ae09df099a3953faed448acacb18.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da768a62c6cceb43813fa72c5686d709',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/45e5e5fff5e5766b7b1cf04e0923f67c.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16b88af74a9c1f167d87f47f43a192d0',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/3ed7237ee8639417169dee0be6837df2.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8928437f6d6a3f7171abb7fefeb6ff5',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/5b96546efef425f5fcdfe77ca8518807.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53221d5d25767e8a486c7ffb6f51bf43',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/c34b4b0e462f8c80a5dc46ec90413523.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1f42806f9a0dc603420b4571792cfc9',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/711e215cadde45ead997b82fed7b0ff9.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3b566446a9564b91bdf0f24165b1447',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/832761bd6781c98f40d90df727ca165d.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8a7f58ae8e6c515d9c3db5c7fd2d9de',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/fd00459065d58204237136e88a8eb29e.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed3c8807153308df1cd8ac4538ad0b7f',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/9f49884eff9b0df02f53136bfe44a625.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba76d5203626decd9a469921988bd324',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/7c8dec2bda28c56dd29b794a4c895c71.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80c5d55b7feb9df09d58a2265459e876',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/58a1e627172067d414e4474d3ad01979.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd53a6b9f2b1aa56f35dec2eb2935b886',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/a449bbbc228f2921f66ae29c312277e5.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f19591fdf20231276fc7cc5b84277f3',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/6dceef17b56b0a2b4f7ec2a948c2a21b.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4572ba58e811465f129f122332c4d6e5',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/79b419464e345bc562769ba9b1ab7c5b.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03a28dbdce7e070774f39d7f125a3d3e',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/c726fcc039663c1c93df1361bfd74af3.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38b6dd0bc5fcf459b146ce10d4bdaf97',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/6119f41c0188aa43bb060895aa0bff51.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a13ef2168a8d97ce492d5a83bc57392d',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/d75eb8279dd097f5e245752d3760c273.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b13ab825cf227a17985afede127e2f7',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/6a93a7f5d3a5007e6905bd2e3d224e5a.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f951058ff7dee50ca06d55d7d9a322bd',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/eae8442655e92220b5cda6dbca324e0e.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fb9262198359455f4c3c39bc57e8688',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/96e430ba999871f4d3085ea82bdd8566.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '699aa11ea6a1aedf4359b38f9e06d02b',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/27364111edbcb1706c01b93351432063.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e7479878481c23f9f262ef99300edc0',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/e2513bce546d880efdc8caf76711a244.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25563574de2513507db6137056faee40',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/4dde2f22439e1457f20ce4c0802befa6.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '27acdf85e677b7b33edbbd78f7ccd682',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/84e431a819c3e2df8ffe3520725cdc32.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1684014b2f1f02fac5fb29ee4cbad086',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/c57793bfe37a291fd4b5bf8a03f35aa5.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a41ae25b11a1ad76f5326253f4d3595',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/bc10aff7a0ed9d74c90f325d42fa3f07.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22d881449d8a60bc2c98fcc1196452e7',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/3dfdb359371e68d66adbaf9f3eb06f7f.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1e188fcefaebe24f018c311a0edd369',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/25ec71f1406a1a419fc9fa0e84eb0310.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6206b35fa0168042b8d57de18cda47cc',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/1d67bca18853a86aeddfc36f371d1fc7.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2cf1dc2d84ed72c3836464371b0ed56',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/b8b6563d0df329b83ff6b9b66d9a77cb.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0bd6ba902908f03ec0ce3c7474375e6',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/f0cec1498e89268efcd990953984e027.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5341c7b152f5c4c7e73b5faae97285e6',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/4e6d6c994289024f25bd37d745ddb753.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfea2c1605a9636467f844bbcdb6f9e0',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/4b626c2f1d623e73dde183e500391828.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '98a9d8c7c506ce8fd8c41355293c96f2',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/bcde6e4c64a29a2e937bb8191fa02ae1.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0266bbcfe8ed37a9f50e404746d8509',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/b69c061d5874da9e22cac7a0df05c86d.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4eede6430522a6dbb6691e70e548e3d',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/a6e1e99fe1a018be111db731afc81c11.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d9cd79532e82a246b49d3c4e2b188c4',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/f388fe7214a4179832866c0776ed5c0a.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fb9e7ac29921ba014f5a538d9f979e2',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1dafa8b43da783b0f274c5e1e3d6811b.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa7300e22ea329f7ce34529740de60bd',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/f629be6e18a10a2745461654ecf4ba7d.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e5201147ff00826ff9e67477c5d5bc2',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/36855d18bd0b1f6db3c43a882427986c.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d1f464a7c55c38137f835dbe85ead85',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/609b076f953daa701d520c0147011e87.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31c829d3c710bfd2322063b42991e753',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/2a8a4b2aaa5cf35102740519a4a421b2.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '217875a475a9f669e50c4cf44131be91',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/b6cecc9fcd114a982a83e8444c241818.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b180fa3a49563e2f1c2e2a9e40393531',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/fd3500cc85babf4b25136d8d18bd9795.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f479e85ed09ef7e11d5992cb1230caa2',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/e35ccb54f0688a2fa363645aac9bb7e6.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ebaa83f908bc2bd1a86ac60d8fc8e84',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/c3816bd0b7bb7d8a29dbdb099e104fe8.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b4d7728b0ef56e88286729e00714446',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/dd8f125b6a9a0bdc0fa96c7594633966.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a50db783cfcc6ead869d513141c91c09',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/22fcaecf77323a75fe38d5e54a653011.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eafd309c7391c50d91f7f4aad8b97f12',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/975099a6b2eabf56e3cba047e7b5ce1f.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2a76764e2f6b59487efb57f6ed059b9',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/204047a25ed3a3eb2ff76bce1e97391b.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '137e0479d8669d1a44054ff8d777eb12',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/adf3ed8e7121acd666edf122f3b02394.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf9b8822a2bf7d9addf7e247da80ca9e',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/ff10e060cde78b494114b07be9f469e0.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e6955875ddad2d78af1b13690737d9c0',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/91e3e7e9bd2bf40861a1dd4fa139b374.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b3f7ddcfa218b86746ee5186669a60c',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/d09638d0d10b06b902b2d21e7bae307e.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c274e62ded4bcc04615a06ba91b6ac02',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/151b06f1aa534310745ff0009a35e511.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '91904a5ca48d1d5880a0cd02cb00a37b',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/721063f945fbd812562389cad91d151a.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '750ea5a6366ed07cf2896cb83751991a',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/1a74d3480dcb559b5a3f35ad32161d80.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c85dd7e97b698f44f02d0e0a45e0793',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/26f4810c44677a58e7bccb4668d70532.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '240921eaa5ec9a51509270016bd5d295',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/cf3f1f477d9708293f3d138c7b4779a5.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73ce08ed4070e893f1e04366876b1965',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/bdcda574da29a253f9db039077c978ee.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4341f74297bc7425000331fe93f25c0',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/b9f4d79da1532f86c885dc3422690b2f.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c284cb13aa02e45d9bd8624853da0d90',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/9c8d0cb8e1f22d103649a7bfd88a9c20.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfa901e7f4ee20aae615494fc4125873',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/edf0ceccb1b29926622ae077b20c53ca.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a94b23e1fa543d20c063cd1397cf1d22',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/005e702c834834886b10615fb5a30579.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bcfc6bed104e07680bef70a646271302',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/75f8545b196d2e4c6fcc88510631524f.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '605bca35a6c21fd5b85f48f50c1a17e0',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/48a1e885b660c117fa0443d3ae973be0.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8968aaf51a399aa75c985ade4f7ddf3a',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/713d9939235d62d7b82c0b6ac0ad249e.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '368c3b271f01bcbff685d5df62cf8827',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/25818173063045bd3b6d16507077d295.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '897494d513665c34555dfe900fbd54c2',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/9f65b4be7df55c7d07aad328408fa046.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '236e54d965d23897d72debf3fa0bd5df',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/37893030065e6e866d5cfb6f1efadd12.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31c5be1cffaadf63a1162253f092dc0b',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/4b3bc7a80be7345d28cfcf482f67f36b.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '158220432eff4752f93ffc3880a3fa6b',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/7b84773e600475af36fdc598facc3232.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb9a9acef6f84d6036205498c347fb0b',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/f305d00bb3677ea4be388348d76fb010.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0b44e93087bc01ac0bcb7884a950411',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/219f82250140dca9956a73fd309e56e8.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f0f999082749d5191d17d8e308e33e2',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/c674be77fb7dc0bc792ef8315aa8de3b.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f8e49fcd55b41675130625f515f8a92',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/60b448ae9d9e9c5a72b9155bacd0dec0.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e8fd74502f7cffe68e93f4c9fd2d6e5',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/1b1b255c8b0f8f289a77649971f77000.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c960eee0e339e0ffb530ed4ce1627d7',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/9f2f0a519cfb5b37b23eff513dfe2214.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfc63118d61f8f17cbaf1f372f1e2815',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/a0e0a93c071986bd34021bb2a482f90a.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ed666e3bfdea9ca8f22159fef4f8da8',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/fbb0c1ac87c5a6c6f864433ece957b33.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62f2da4d3f1eafc91dd301de76d01cc1',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/12214a2719a598323fef181f33893732.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06249f72c50e165eac3b35466ed01ad4',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/a3b9a727cdcc422e8b91148db488b737.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd4583a196c12881eba21f700ab547693',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/98105015593f997c01dc2fe1cc0b720f.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '461ac4bd1a108ba035fe7b4a24aa0983',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/d778dffc60f13093a82cd41a05914192.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8913c8f293d5ba594e27e58f0bec0bf',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/ad02bb76eb1c382b0b363b761a0f60c2.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44cea2a52d1262a510c233d4d753ddae',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/ac3fa32aa4e7fade0fbccb0f5d236389.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '374822048abfb84afe6ac15910321df3',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/39b528bc3a39170c6e8861390692ec56.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '375ae11aca8df7710f765513954bd9e7',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/4006a452d195db52dc3a239504df062e.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d6b6debf81a8bebc9ce07f74bdf42d0',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/85fa1910d7b5577db194cd953a8f8c74.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4490f67de188a6dddb15639cda3aca57',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/7d6d5a5312b6c7c1e28b1975cd5581e3.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23435a6faa7ba268522aa671d507bb96',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/fb7552b07b6bf7af56521485a8bcbb1e.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '017ea1ae152d9f1035d39e9c28ab9a42',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/14fd8c77f819b5dc3834f39d1789cd79.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c19e71a6351a2965a38cf8eb0d1faa5e',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/a496aceb5bcdd706a66bef4967a4ea87.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49e390e623fa71134e016d01205ad277',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/10b7051ec5def92071210070b06fc4a0.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2056e52ce9875243c89aa8bba22602c9',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/e071da87994182b9a8d965fdf3cda284.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '55f97e90b8816612590ca6e1a7e97f15',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/7017e863bcecfb14e58a5b4614fb5bd9.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95cc80b7bb70815901694d8ac29d7081',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/152e6f3b6cd2925c8d4b5f6f95b936e3.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf1330280ef2b93ac3c162589f3146a3',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/35c57aa03eac577d4514e846edbb92fa.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '017bdb88d56e307de03adcd6812bae30',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/ed408c94ee321dd74ad4922ddcc46c5c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be26e79a5640412882d1706ba7f5afa4',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/f8dd95c16de995247f7f10aaffb7311a.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '583ec192452ecb52b0cd22fc56464af3',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/44056b85c13bb43f66e83f84aad17e39.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db14f558763cf4c262088a1b14f940aa',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/0780afd21f5568a98554051b18628dec.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40efb481b4e28ad1b9ea81f94b1d49c9',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/6b74250513e1e10f73ca193d387dcba3.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80da6ffc25a73f03cc6df1bf5d6ad67b',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/28fcfc245ea52c07cdf03d2887ad6b12.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f531a44d4e30e02b5ac924e34a87a3c5',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/c256d359e0ac7a2ca76007e292acda50.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '08d9c61a1278463449bc7e3c2d06d34c',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/69364acddf9cd608dd5e34ec2d27732a.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11d895d905143bccdadffc0e82414f45',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/19a21d57b7b67cb3a6e55f3105852178.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8c137871a7bbd99335b5a674052e5e4',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/98d5aff4af08ca7d18affff05e0fe8c7.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5150341e3dfc18bab75fea83210a159a',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/8b64b0317146052eafc130c2121f5211.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83801af1e0600253b6579201b7070767',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/92b687c0b9ca73f332aa84767754e95d.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9930e075feed69c7c2e486b941f4b32',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/820ea60ba6fc7529992cacefcf32af20.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02a6626e82c89287fb41df5582db2fe4',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/467c4a7eb7e06b29d80cb9a6b5055f35.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19fca9e9c0fdc7be75f4af66469c9afc',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/823776a54e4f94f920de7d68a441fcd3.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1489d509ba1ff52a85f2adc598560b07',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/63d186a8ba001749554aa4c4320e9433.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0c65aa17157d5d5b58fc301b349b9e7',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/8a7bd21a08c0483efaf44262058c596a.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3825f9dd88374047628412844ee5652',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/6cb10cc10234f20b4c95551a64f07104.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '593360db15c68832827d377eb0e0657e',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/2e2aca1ae616d0710b61898b8acf016e.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae4215eb87fa0aae17da5c39d789a6e8',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/3ac37d127f3a45ceea0c5b11ad96ccbe.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdf9d418370134cdb3b4a765d3b49442',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/4ff90a9ac962d704520b71a66b7d9c27.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af931591621245b7e2fb694e65f686b8',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/8bb0867edcd2a454a60b223f63e7a963.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3185de4f480f8a89226d91f5246a95c9',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/28294f15ccbfca0fc09da89a93295662.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe55316a3f732adff999bee6d59dacb3',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/5497330976962acc1e392c348b6b6d3c.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3014a5009c43d7dab4f74348b225f7f8',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/e29d382480f222b59364a452680c7094.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '974fd6f19930d4a5a51cb247a29c1da0',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/9b921568f32edb18ce216b23f4edacb0.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45c0f19b8c19a8c962efda3fe7829c8b',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/a4928540fc059a823c6ca00fe53880d6.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a61d0ff7804d5f939575d0b5bd58596',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/73e1a8e08845837e524dfce96f6cff4a.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fe9a868b2ad1de0e6ffad435e364acc',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/5f5f51f727e6ba4b031fea5232302be5.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd36710d5b24ea1e6c6c01df7c0ae142',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/844c0f9875015affd1f348de82ea02fc.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b13f5ad84fbe58d2807cffe3f0f86383',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/9bf37300a091c1568e6c0810a4df497b.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3d5829c947bcea41b378e8b7bfd6029',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/6140a0c9db9ffcce83ed55b8f7b75118.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ef3dd6e5427b2473c03d4806fa35219',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/638715d68869a1e940cbc2053627acb4.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '158a02191b5bcd2c70cb7d8c298c5038',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/3cbe95e11e8d456b32a13f104a10192b.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a5b1d913adfbd0883dced0569bddece',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/dca1ea42be3f955e0a9b4fcdc8fe9c92.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39e0e81dc4b1172839b10aae74eccdb8',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/8f41c76c8ab4418dbc211e23417d6da3.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '889a2a6a91f389a5d67798fc5541f61f',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/ef397c4fe0300d960fd8009d6302ac0a.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '824a4ffdb5cf7ffca2dbe3016a292751',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/a01fd97aab8b1d8eedbdb6c1fc30f48f.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c60558512dde1a5d0c8648f458fbafb1',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/e02e4553185a8580723ebc8ff7eb5787.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '11e215973ebffe2ef996837f05973acf',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/6a41910b270fc2d03569aeaf341e007d.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd005dd2a36531c1da95350b6c0fac658',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/479275f47b361028c8770a56adb95590.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33006077a5dda67db35d3ce81cdfbe2a',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/919371bad60349618b6ad9c18c381d74.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e25944c05dc69321988d2c07061e1372',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/30724613c95d7dcfa072c5214528b754.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1eaaab970d9c21f9c4752c4a51340a35',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/a7a7c5123b8ee80a40464f121e07db62.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2ce28f8af09b0b72dd56ca78ade9cd4',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/fb173f0040161fd624272f15792741ca.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f1f96a14af0a04e07fb147c4ef2b51c',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/e02ea23db97aeb381b6a29432c5b1916.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d37509369b93c6b3171fa0ca1aa9b2a',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/e502ba3f893f8ed48312617b7abb03e6.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b643c751e4075244f431c6a6654f9a9a',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/77237120ead66ebc8180b4edbc8e06a3.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b7f0390a9f8797e3a9235e105d49a58',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/2d3af29948d2ade64eed147a02a74a71.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f5c0a22e215ec511c6cc0991da750cf',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/2cdc039bb4e2959d0704761a5d2ebc09.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de8cb1671ce43c35ff3fbd52aadb1709',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/733d13d56c3373e47d73dbde791875f5.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '838c741b004aeb6c04ff06f470aa1a24',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/602a755aff69b38d5f5f8e6ebfaf04b4.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da381abfa178ca23b0ca924693e66d73',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/590c375a5108f049a6f938066252cf67.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '916b23f7c6678c5c891370194fe58b6f',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/696edf97d87497497a8b4d54d9a391ea.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db62b844839a4ea434a567e31f3fdfd7',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/5703df5030214630810316a4dd3c2b2f.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebdcf1516baaa03ac27526421518a410',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/5cec5e33779ae4007c3c1daf697a0fa6.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68ef0cde9d288ac78fd6e6d24eb6e349',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/4a47a9f9f74d7ecb9a5a0b27e9b6e642.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd1213185675ceb7adc160479ab888b2',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/7380f411fe338336b56c4e465d0f0725.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96d99e0b0441da68ec1c4b0f53adb61d',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/67e7905569f5ec076704ae7065d7c95a.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4feccbfe333a3b365b0122d8bbe64fac',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/5972e187e9172dee3fd64a18fbc62c26.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd1eff1bb6e6671295bc0cf53f0d623e',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/977d1f128da33e3da1d1a9a3b57f3732.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d4b03b131a25fb84a2fe3e6d7f842ff',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/adb1f89a6d2cf99239477dd63f2f46f5.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5661de82dcb417a6f3ac0ea25692c5ca',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/b4df0b5547eef95c0bf42a8a1448e4fe.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e47ce61a986748e08ca4ebdd2105327',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/390ee7878542015bb7f1ef9c93c8f570.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9348b18e9fbefa3f04b0ebc5b1a2b32e',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/e674c5717a1e286444fbf2b0770730f3.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccae5e68220d4a4df4908e6b2b9d7bfa',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/b1303d179027e1841992189edd6d6a22.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bae0d839f0735e188b74c6387979cf8c',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/32fe2c47095daaaa48c153e4c3726536.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bb906d0e24c7d0eb0baaf454d0aa649',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/9a4417a74f09106c8df7bfc308fe18f6.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '562249c23ca1869b020057b8e4dc8406',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/e4636b19b92f946beefe0035483a4f9e.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51911170c5f9a9872fc1969f49be1935',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/0489ebd61d633acbb026cc9d83103975.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b7b4d0c34c19ad451e4e83210e7c30d',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/f5b6f665d2c2e68b2cc8fb8da87cd40a.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5305d673970d135cafa41651700da15',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/377f0db836e6083942a3cbbfbd064f15.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94617ffc74b05ac485f4f2c0d41ad6f2',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/9a95e0a5ac6f48fce29e98d24b4934ce.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc07cc6cd8ebd8b32d9a3af001174ee8',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/4bb290b163f3cee297b400434a573ef5.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '385b720aa2f096b9f1cf63845d02df69',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/03a1e9045af773fe47f31a4732f8bb7f.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93d8d1fc05c31ebd4c41bf04330d84b6',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/497d0ab7c43042a23e755cf67ed21a37.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f68257ccf9fd4819d5deefd24836793',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/06608952750ba0b334a7634e1040c555.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '796d74fddbbec36b9bad474e013ad72e',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/074411a08a144f9a4a2d95899a05da6b.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36cb6238a12b2bd8aa1d7064cfef1ccf',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/c6e56ed3e4452a74601239126c73a269.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf92881a7041b1df99c595d85004d935',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/d36b8b235c6b9c4ef83503fef8d4586f.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97f406a2210b4002385ac7c2fab78222',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/1f2165176a5e217abac21afa2a6b6c82.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50101daf9109581790836cc3b08d39fd',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/6451bcbfb40ceca08718afb182b7240c.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c28d2067c5d8b01441d2941e5598a9ac',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/145f5395e322180a2d794c8f474283f1.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6abb7452a6d6178e5eb7524631a038f',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/8d41f663a1afe4f4500401b4433294c0.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6cd90e33b69cbb4f397796b3c61cf71',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/37289aaab7f14863df1d7c9a365812f9.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cabf532748507184858c0cae3f17dca4',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/fdbc2683b97f0c4ef93657421b06bba3.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5368eef59ee9bedca3cb5e7fa9f17f3',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/fec8b7eda77697a9f571b4b8c0f05a26.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1eaa1e187974b9bf179bfb8765405def',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/5f71f46368bbfefee448cacb0c72c4e6.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fe4a08e929452e99977da09b3d40a66',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/70719f5b7c13d51f5f804eb5dbebf426.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dbae62d0bef56ff15615a2e0a42996a',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/7aeb15aa7e385144533560e25f4d1273.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc5ddc2abd69535a24fcf001a5ba41db',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/5c6436de6c23a8ff311dc75d2a915741.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8553a2068a51a4580da315a68f81d6f',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/901e407f4db6aa2a5e7ce5fc4f0e6e00.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae6fe2805d6b7028888b7199218e1ead',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/8e585170ffde9b8353ddb459d1ce99c3.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb27e8b23607d181cbb7de4adcd89342',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/0cab0ab9f198a84b1445e067187a5d3e.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc165ccc09365129e8040d527c0bc8fe',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/6d7de4744507271e5e7a5cf01e320371.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7adb19daa25497c1568e2c9747fac10',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/274246c4eb5bdb2a61383837e61f2739.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f843d730e884e91152ff51057bc5ba41',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/70f28043eb5cefc6795a31c9c6ff509b.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bd28a4b2f3071be1045a64e4fb0a062',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/3e52bf273c61f0c2d7d360cc2eb78dc9.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a8b3f1780dd585315ab026d529675aa',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/25b04b045e59994a46eb61dead50f59b.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '458c81c7853f54feacec7083f7e8c38a',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/ceb84b2f2884a84ee39e9073d60af5c5.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9328389416939dececbd3e9d6eee6c50',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/b23dc6ea32c3acb6dc460a276977653b.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64e629fa0964a54c103bec957c281637',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/be2311f77700e5578129a77a9d8e4ac3.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c1047a4c98ff6a1d5f777cb692675ce',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/acfc78ac93d029e346d8909b61b126f4.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b46290a6bdc7383a670fa84fb123086d',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/c88ec0f3d5671aba5edd9807fea3a2af.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '839bd8c94fa5a241e581d9ed1cab2150',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/7897bd2003e491be08916fd5cbb0877f.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '371b2a85b83d58d20ab146241163380c',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/ae8a0fbc4d14757da3c12aac7d811bac.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c9151e6fc138e26abc61972904846a8',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/9613d7c0a514779809e0f5730524c36c.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59c834f2a8f0c825da57f8be0bba5826',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/51d6929ca6d76172d7309bb74541fdd2.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8431a3e78231622b23411e35ca1db46d',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/43e2d9ae18c18cd5c6a9840b47925413.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e6837b0a5dbc559db6535f59e381e87',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/4b3f87ac0a8b78a7b8e1a38d6c5239b1.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f84acdc30fd008e12ad5f5bb4d98b49f',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ca31096284f5453510c088bdcb663a95.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f5f8b8f20d2c75a974d243904bb05b03',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/f2eb68e91fbe7a23558778ed36d16ea7.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b1ac67028908b73d67e2fc99f458825',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/f6ee4a53434427e4a91418549e55dd1f.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b164a6d5a3e6c499ee16a652cb64b5c8',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/0c7ccc4b7dd131450d485197112ba85e.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13fe1324fd005889c2fb6291d54d2c28',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/33f2cb5e291e8dc1ff69a6dbda6d3f65.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67d8390d6066a812088b65709ce390d9',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/8ba8ad1a8637f9518bd40b873605ed66.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ce65d1140f9e38e7092bb52e9166bad',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/40231b6c1e8b74991202413edbecf6ca.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f71aa2cc7b7bd91a56721745d182a9b',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/fb237008525b5a499c2cff5611c887b0.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66588a6fd8f44571a6fa3ce231d0396e',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/c6dba6509898a519579e61c4e4b06b42.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11fe29474c603a859e60ef9d13b6fc1c',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/9cfc34c6120687cebaf783a03ec61f48.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd11d3c8c74afa3ea03b1cd0773b6a883',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/f12966524916681ae06511f19088aded.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e44b7a3b721605c724e7265a927995a',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/eba9d76d38c6f183fd35732bc73ca0ff.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a5c8fe42f353f40fea7d3e9e4d8609a',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/33a95ca58d7d9e7d563ff21d7504427f.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5e55429ed13ff595fc8366f7333ec55',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/fdea71aa4312ef12cf81ff865d2d2a6f.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6540438ef5d28e1d1d4976786eec63d6',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/594e6e7a6fbf3fa966b68b72b745d826.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9acd52cb4d249937726b6467b31ebec4',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/984742cbe67d86066307a5f128588b8f.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd69860028550a68c11d94a86f86361a8',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/5e3c0010e1b01ef6576b04c519b7ad8d.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f939fe7817f60973a7a635eab4bd2988',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/639dc8be138caeb4f27508d891c6c8f6.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6c73a0387ef7ec38faeb6304175897f',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/5f2066d365a496e7a90f8b13a1304425.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dce73c5001f71ae09db6e702ee07e4f4',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/cd426739e12d99a10e8ee77678e8f362.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13955636ec2bd53c1c65b320cd28cf3a',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/0e88a5b9c898521eb37f44d7ddeef3f4.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a112ab6532afc72a5b32acb1a2ea1518',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/7dae63d93cfc1d51e10f353f742972de.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee094378ae3eda0eca5e47b12b15a993',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/0bfa7d766687d472214f3c4306e96864.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c6c15e16e8b6734f1892187a8c53111',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/abbfbad4145ceace3a69a3e87c2e6945.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c57c9a26f1ca5531b692c634aa6ccb5',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/fda9e9b7373e6d8521fa0cfc3a3fda08.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75611a38108eca9dd42e311461b039a0',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/cb36844e2b34fd716452010c139996e6.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '517167e4a782e311ac37301be826f433',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/5b5efbc6417f5aa57ccf70b5f3c664b0.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31dd850244c1b0d31e552c240352d959',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/3685444923e502add7ecfbde79cdfb24.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e19f988b211448d6a2c4dd44e08592fa',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/e46c5c7fc3d42a134ae7c6651c5eb5ec.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23480615ee3d584ba795f9bd771b631c',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/1224ccb64187ad2fdaad8d7e72c74c52.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ca0839f0e1268d80fdc3f628864908b',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/8791cd89cb348c17737043c7ce963bc8.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '530b7d36a2ab5e0afdc1afdad7180d53',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/aee04fad961caec49872a0555aced89d.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1dcafd43839025c5f1ef2e620664b89b',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/b144c1827a029fdfeca393e45c2a8337.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7297c1fbfd255811baf1f7a7b66ad9c',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/60f9a74d0a8e8fea9fcbbace2df16ede.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b099917d05082f2e31da035f09ff319',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/bf68b14c2f894a1eadbda3b26df88872.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd89326cc9a40e56d762bf29e3c18b418',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/926370d1897ac67d3b9f648bb591e17d.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2df07e6920c83940cec6cd5841ee1f7e',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/a1fbf757ab838b2d6e535eb3605481c8.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58584dc11fec5601fc59c870e1949852',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/9302b069ee77bce04172693767db4fc2.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab25f19bd735e3f407f2b0c5372bb0b0',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/49f842de328adf07d239d3333fb9a805.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '244bdb6dffc99b62a2f95760e3689c9f',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/712ca4271149f2f73f056636935b8c8b.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ab5b0c0067579cc98f1e1fa8b092f7f',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/6d379e1bf543480691d0e03c9277e1fc.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c65e277a298570022595b82f5ae2ec04',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/364abda4e9011be672c558584dc6f9a2.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccb6127faf344f01bc96f026e471259d',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/4f86b4a1248a6b9d4d1ce5937af398ae.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdfa0219cd5f451f9813ea4c61163250',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/d5067c020eb72c3e4ab6f2badc9ed73b.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78932b090f5a4d0acbb76ac466f211cb',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/f8905824ee2d896e4875ac33ee6ac3ff.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4451e7e151154c2d1cb3be6a54e28b7b',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/40719f175cd1c2c22d652d8c3aeb2001.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6430f472e482523010908deed482e75b',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/398014a758f1eedc0821ec974062141d.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3901def8ef7f3148e2cfb9db9934fe30',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/54c56444c1e90662cd9cd7f42c537d68.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77d9a442fc576df672958f1ec78d1bd7',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/88c69839f61b68125474a3427b538a19.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96923eeb5a399093c9ea1c8f443ef192',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/139485c2732194eea7750b25b83e18b8.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79acc6ebf491912b0eced0a1a88b4bec',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/8a65ea3903a8bd29c4b76e4e3435731a.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b55a61098f8f7375bad9122b61b0220',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/e3e607a502c7726ebbcfc1a6ba5b8ba4.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c98978abeaac77e5c0f8957d1b169bf',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/b3a1ff398536d92edf9adb711cc2c512.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '709f9f95000893caf09830e9fc14f695',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/2960e3d42786eae811e75457000094f7.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed42ddcb247d6fd1505382e819b822f7',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/11d8382d1916fb1fef34fafcb0b87a1a.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96c196517c51a33dfda548c4b20878a9',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/f00f44442fe59f163d576ab6fc6064e7.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cce99237ac513626df926fb39e740854',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/e3b2eece6c42023ae52bb81df53e0c57.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd977935796e104a43fcf6ae250374183',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/316036679fd0dcab5eaf98eb5e4857f0.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6db1d2a1ad23084667eb1abbb2441fd2',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/21a5f6ac9c92be86c551fb5e4a2dfaf6.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0ee21f34002a3418a81b811c39fe208',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/78e658365ccf617ac4d9283948d3d542.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '783c060b00cbe3236bf13b74eba35efb',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/1559ab61bcb52692de5e022e1d4c0493.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74d8f05e20c587e6fd5941a658c48df4',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/fa6872f2e85a7092ca6129959971d55b.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6a09e66589b7b96e86692141a65c205',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/b7b8b16d5959ed6328f264677b5044dc.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b566841e755e06f6baf03219e22de676',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/f6326346528056002c6d21ef3a22ef4e.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8985250a4d3b5c50262454aa71ac17e',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/d6af571f591b44b5bd4f223eefa58039.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bf561606c77743f2c762485642643cc',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/208d4292f255897ac343caaf1990641b.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7937db992586bd6078321940abccaea',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/ddda36473b5fd9f5dad4fff2f3aaf896.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22f7dfd8db72d39ae2bb50fe7e451eed',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/90fba10c65256490b15e6b50ddce965d.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9547cb7332bd66a6fef6246fede7d25f',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/9721aabc6081bad51b068e9173ffe76f.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f371bb4f2db8fdcd71fff0b8c71e2d0e',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f44a9b8ccc3e0fd49f1dd13e54ebf41f.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '926755c3061e5f208244022848b5a7a9',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/2dca72ad789ebca8836a25a4208c7c4c.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec115c73c150d865b2ea772f4b6f3f0f',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/9f50340858ef5737f3011e227a12bc8b.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '636eaef6adbc0dd3048a1dc8ddc6ddcb',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/31d7e1d52453995ff434efb82cb6d676.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb0934ee79a07685280e27d936d5d044',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/445cae6bed336c0ab01d386ddbbcf0fd.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '760783dd018e0bba6611ccfdab98272a',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/45aeb321968f42cfa2bf6471249a8f11.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43c92917e2c5b562d04497da15073826',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/5c5af4af1106a4a1caf1a98d1cb6f3e4.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '730dcea50d1abe0abc538f9bd1be8048',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/40a1376b386f9d92931ebb5c79d90d8f.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48acbea9f7a0403f96f16b668b11ed22',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/0a622f4923ff72e6055ca4fd24965cdc.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c36a20f5fe979f697b8e018a1a91963d',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/6ecd5d8be54f5c523145ba8dbd2649fe.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6bd90c787047ecfe29ab28f9e2f71ec',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/fd078dc236e11bb3648ac11d70fd9e20.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '697b1b715245f1ee64a07cd237b3388f',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/ac1ca683aa5ed1e6ace7a36d0640ba3b.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4fc3f86759ab4200fcb885e014350fa',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/be9f0188e0e8acb9ed652ea42c252bb2.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07a28173c03882efdbf9c0090a82d675',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/8a7428bde455ac5e1cc69a1b17c2f79f.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0070f86d418ae8d53ef925801c153bb',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/33323ec87e1939f829e7b2f2dc938617.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36c7539bb44468d40b33dffc555040c0',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/2f888ba1914d7ae67f435c1ca8019ba9.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e311c09feccb91cf21a3dafc8db06a0',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/e89edef24ef530ae0b4af88d54fb3303.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74ec4ea9ed85e66768bd57e7efb5ab17',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/f6745dca16b56ed766b9b66ef4d585ee.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d23b42abf882988a91e957d7d3d6c16',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/7d66a08552fd506c6adc07185da3cd14.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bf453441aa708fa39d771f5a2d8de74',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/42f3f2f073b53c0fa775563c4fe7521c.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '768ecadf390183a985ab5d3332c22855',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/c2d44f72a27c1757936de56fe4152ee2.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf85ef388c5f846f5d7811819eaf33d2',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/b88614a1c9ec99084811f69103b19136.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf739588ed5e7b145be2245d2da4e7f7',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/2dcf76d38992ec42a97bf7793ca79e56.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2b0aad27bae1ded0d466aeaa83474b2',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/c90da83d150e63500fbb5c72b69a155e.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69791e80cb22252277e38108dfb703ad',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/0d958dac6cefa309ce40707183bde434.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4792311e714018ed3990b550df0c821a',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/9defc6a36feef98a89cd50e68e8686ea.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc5a1a377b5b822ab97a39287892ddc9',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/e27c777323a1b38e39980712a5101227.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7060bca91232a2d362a40c15f2d8e55d',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/d6610e6c58bbc9c582d354620d799159.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22a6e4356911fe5468f7cbfd8c82357e',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/c38295c536f75baa35a1f70acef72b49.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6d384f23a11a18e205863eb4cfe0481',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/5b5e2025c411e380efebf478a11c3e39.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd163200bec1c1d35e5f424fd74082f4f',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/3cce435dfe9291611635a4b3812911eb.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ae201daaeb54526a83dadb8a1a6d886c',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/2cd8206db3bc862833be73541c973199.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '653d36eaaf296ed83e12be3c1a4b4386',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/76c9db6139862a71a0a785b3c1104e6d.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d6df13492062c8e80f6edbed047e539',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/1dd486ae6a50a4e61b6f26a64c0f2fc2.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f70823ffb682a7fdc49961cdc499445f',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/0d9e11d9b9f233998ff8de58c827d3c0.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '806ecde5428ca2fb02a68328c5a31544',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/5f6a85647388761c6e64f724450f5a76.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0815632d74f9d678b90c26d1f9b4c4c',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/3614ba7739b619ec97938334d34443d5.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b40735bb5383965e00c30455ef6443e6',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/5035bcecab4f634b3c023812ca587e2b.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75c6a528b1279fbf47a8640b103e5206',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/3014ad49739e3a728938b1cceeb2179a.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85ba557235c2db58b76a3790d777520b',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/1e9873c784b71d7c16625fef6f1cf74d.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98ae936c6ac1f029baa4c98fefd536cd',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/3a0a3baa0945e6e68227f328bd04c31f.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa2f2651b3537e245d5caac6cb80d712',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/d3771d6e8eb1a7104c0bd9128488e41b.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16e3bd89e769d0cb85d7a3f462051cde',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/6335a2acb75c2a91a33ffb955462542e.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '451b65bd1141a9b070f0f263ca3d0999',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/b820fcbb6b2224f5d69fb2ca08b8e519.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28818440d99b5494f2e1da5ccb1d7430',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/f7876938231af87e7efff08e8d0a25da.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04d87e078d5503300c53c09f540cd376',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/324ba922fc82e9286a163f936784a205.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '41688e1858dcc74ecdc03cf3332b8cbb',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/6f5184103bd685d36c8c42213b72c177.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b48d6b001887130e9189ac19132d06c8',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/4ddd29116c93680c65f878cf777f4583.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8135bae9cbe05513348f7b0db01f1493',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/f3e2ce1087e9d5629a9e7fdbfd27c3f5.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3283a8f82550a74f3a4608861ce1ba9',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/12ba6030e2c1cbc46a42107cb340fced.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4df506d8f22b8291db3a941c40e7bcd4',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/f4816fff34af43c633b020e927bcf55d.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '208fbc39caacab88f398374cc04bdce9',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/870e3f71bd3a725843abfbe878fc6401.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bddfcd3c1a833d4dfe019bf6e4ec34bb',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/3afc6b5c4139eb47212895480b92f9c9.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b632ac3ccb775ede96ac853e39fb7ebd',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/73374e93ea42f163b9ed4285b7e30760.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d792f4f4c9799fdf7cfc331f93e8557',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/e3e32c6bf95f296a5dc07f7e91233862.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7bbf1a9b24fa99d7a9fa628132953ac',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/fbc6fb77466d78b4d124368b7f1b6896.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48429412a7a42a6816d702d2c6139934',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/cc1a71f401b64b81616a38e9b6524cf7.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74ebebd097459d459cd9d4a0fcec7d1a',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/fb568baba2aa71e4ba56d3bf46fdbda0.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '029437a23e8216fa366902da9dc989d4',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/5b6c95d4fc3e2bdb853cbd4d88e97bae.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fff01427d4faccd038aad9af0ec83448',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/581c20f13e9089768b6bffced477a047.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac6c2a96860f8eec7f33bbd76fb6a5b2',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/a7f9b68c42cbebd70858117b77a44fcc.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81c51ee4cf9836ff706f4dab445e4d4e',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/4875424f4dec1d9b45b297a8b949ac92.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '906d9c217ddf2f508cfebe974222eb77',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/382d0220f17a13b53ca003e51ed4bf5b.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53ca2f8253095c6b0e5f358190729fba',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/5af710f824f9449c8d18f5b488256660.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5d735f251b5b7e03aecdcb80decf387',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/2f690884a5366b63e18274806a4b5e18.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af94c53bb2152464866b5a241f321df2',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/152d98df318c8e85cb2a6755cbe898fe.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0d21493a5827604c6dbdf4b2e550bc8',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/d5915da769853f948638997609ea039c.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07535d6bca62812cf5a7704881d57cdd',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/3fbbb493830dc3ed4aba4d9bb21e24e6.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dffb209ff86125224e50ff65d72a2fb5',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/cc94024812dbf544b9a0f7056e13f4a2.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '341be1916b71ccca2a4d911ab9c97321',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/c0911e4d3a5ebf4762a85d534068d459.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a75ec3ecfd84fbd316718a189ffa5d1',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/8c4e222bbb6b1b705c9a92386eae8ddf.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '25714da744bb3be44b6e2cb4782ecfba',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/641085d2c5b679667a7d583e004adb4f.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34d82386413add3198dd6728f3b636a2',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/73d84f5a4cd3507e08614fa87b83289a.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43f3d7e20ef66ada35e8110b3c2447d4',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/79da3730686525c1573f326224df65ec.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6e05f9ffd79c40ce39d4b152a5916e1',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/9bfd7e4e702ff5bb8063d14e37073fec.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ebd8892e8cbcbb4554006d956e72a35',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/6e72072778c3d9af8c8841fb67ca2fd7.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0d56c15a1480c1160c8e543c48603b8',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/50070789495e96eb456c44a90b86e256.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b990f81721c2ddda9722e8549a7b964',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/e5ae0edd07f1a79ca295d7dc7d370f0e.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9483fc90bfee23840455d5e2e72f5bcb',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/e6ce4668607e2d51ad16271096150bb9.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78a27f4b464afa823482db4c86b5b9b7',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/3495b06b4a87c890ce4709dab0f948ea.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c93f42c41315bd7cf366c25563262051',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/7d1bc7a10fef9fb4d319ee80689aa48f.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '339b6feb7646b83e1ba3bc628ed7888c',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/859182cd22ba86060cd93d45bf7720d9.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd40231161e54c4e3f37cd44eea4018f',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/6332cab4abd8c5206b329c42258ef9f2.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e231c3180ddc2e62de007f3631cdbe81',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/d55cd23b1fa52fd126c242ddca96b8d9.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '736d454a918b803e9120a6b5de446caa',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/cffc8f2e45969211fe5660555c818995.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36692cc51d10669566fa2e56ec19c0c4',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/7430cbec3d2d848ce172b2525ce90d0d.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf2609ac4218d497638706e212c8fa79',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/d2f915d9dabfa8b02b9845dc4eeebae5.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b14e9fc0eccb2b8da8a7140a6f3b2de',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/77e432bba171694fd4cba1083e5a044c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb3ead3efcee88a163a3adad9c9a81c2',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/f6395bdb2d9a788ad54ca2d85c791595.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e4b430aa5602a179b2008d618cd8e98',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/1ff2849b316c67a388cde2e4326f2545.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '224855142e8c0310b67b80f3bbd7f632',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/e5133333e979421cb5192d6a68c64fc5.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9a6fe7d5ba12bd8d8a25613e791118e',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/c04a4a8dadbd03577f8bc83458eab827.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c946151e810849b8a2235f77502958b8',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/a2a7821c14cf3d35f87193abb0ba6e5f.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c37a94b859c3aeb593e897295dd2ae7',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/94b4fd4121668f908fd1c61c637cc9fe.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53a272b9625a28a306627928667bc3b3',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/52fb711ec6ef0cf7c7bf3e9052e90662.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8193876e7935356abb83f66f71f2cc95',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/9a68aec9e09450a7609cc9823b906e16.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5fc9001e4004cd9c60354c8a0cb5de8',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/b7001b05894d7ec128f92cdd44da3abd.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db806ca50b308db2d79b1350c7f3d94b',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/f0ae18cda1625cf0cb76ac73883b8958.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b18ab3113ea4d512ec3099c3aaccba2',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/566d4f827ce373f5f799d42db82cfe07.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c1eb02a4cbb025f512949ab90d71c74',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/eb29b7aa05bc06af1efd5a18006c9545.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c39910fd43df948fcda91ee6635ab176',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/bf5ee140f1a90ab2926d3170cb067bea.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2601b1a6fc19abec442c224b34690c7',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/25d80b0cfa40a152124176449fdb791c.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4b0aee12cd3024f4deb99ff888cea05',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/7ea09399cc1402fac1372420f1965f13.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '252b21eb179703a1137e746bf71fe631',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/2c26bf181a4365f5ab72064d269c1ecd.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '09520e3cd8238f240d8d445f795758a8',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/5e772d6b5fc1dd9903d16f57b34eaeda.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '4d0e64959a5794a73fae6dac8d3ba20c',
      'native_key' => 1,
      'filename' => 'modUserGroup/276562c3503660d8a64cac863d1353b0.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'ac84e6569fa8f888caec99d246fda220',
      'native_key' => 1,
      'filename' => 'modDashboard/66c6cafd69390feebf3d972905ebd92d.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'ed7e22626ae9676df16928c1f1f80559',
      'native_key' => 1,
      'filename' => 'modMediaSource/3ab45783377242ae319aaad9bd7e81e4.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '1dc1b5f2a3e5cd879b04155df19a7ea2',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/c2b70d758fe6c89ff74d3046c8ae65e0.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd381b7f34a91a1055502205ad93d9684',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/7c5b5be8958fd36bff6190c84118d02a.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '37bd5e34d98722cd4aac92bd676760dc',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/f45bf7d600fcef02ea1c9f6deedb31a3.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c57520e6f1644839d8094be734bbca25',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/706a8c29b818afe080e460be1cf7d10a.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a18095dcfaceabedf00ff79b90eefedb',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/a17dcdf0e35f11fc4d81a5625feea125.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'ba9d4f7870ef6a15a029f003edabdb40',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/45d3aa132abd763cb68469b12e6719c1.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'e9df01e69a6eb12bedc3985ca4bef082',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/c90633c47b446e0c17dea12022fc54c6.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd83d0f27e4ee8c3586941bbb400bcd4a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2300ebe372e19c40f344bde6168358f0.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '83f6fce19939edfe524b8c538cb966f5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/dba5fa4f45668aedc3df9f1a102447d6.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ab174b272c8c45d911a43c4295a1bf84',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/347d007dae0578f5fd4b132e27f15de0.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '19d3eb6f99ffc1c92e6758dbb86d11e6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/8aba2d214d944f7f55cae96a3a3a003b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '6901f2e118ee28e245b1fd46308c9e5e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6b7f33eaedf00d7583a1aff66ab2d5b3.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'cf725bd89c257f768e1ce6fdd4c37b3f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/da9a6807628cc76d0c0ee5fe416ad2ec.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'c548c1cbe9a699c61eafb7fc743aedd2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/051744028e482622c4684d52a194577a.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '47af8a976e4ae9aba385a71dc7945915',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ba3c11b03436b55248b0d306106b0050.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6e7d23bb97d491d1447d29004ad9bd66',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ec03643add26d4fd6b567aa7fe49dd65.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e24d7b0c7d298bfde4580902064db4bc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/90c9a692263836ee912175d5faf6ca06.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '6c97b3a41257c0296e200b1ffcd56bb6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6df4c96ef5b8b671f714fe8aa4cdb9de.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9c3d9f60be2a3f9751f8960747546ede',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/49a07c03a0dab66c895af2e126f1d9f7.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '03ffd7ea8d0dd2b8ed93fac0620ba4f8',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/ac3a9a7ab7509d817fbed60dd0001f72.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '397e41ddd42cfb4786c507303fff3bc8',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/8a84b731564ae9b0846c5698f6847208.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2b0356b1dc3ed24aac16853db41b8a61',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/9e7b5f40df99a384c58084e42bcf0726.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '27f58348fc6414fa830c811145dac00d',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/8c74cf9080f0bffb1431282c642e4940.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '71da5a4336303e67f49cbe18f2077e12',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/5ba39c2bae2a53f6e58697606e13f6b7.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '75c9e1184dc04098a83ff7b5ecd90281',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/22d7fae1d4402d4cb9895655f5deed21.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6bf29a6dd2e08ab08ec74a209dda9d0e',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/4fe056b8a416de43a2a93eee5a14b435.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6ffe934798589587ecc2d049fe90c036',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/e5b4386f22ed744642a2dd7085a90986.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b7e27f5e654f506d71be3c1f563c9268',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/513032282c641da485ad530f2a41fbfc.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a68d43f016d1230601af97dd5c38798c',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/8b5a9d78976e130b5bd6732da6f5062e.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '3614a8a0144643a567940ee71425c339',
      'native_key' => 'web',
      'filename' => 'modContext/3fe83e82d214c949098321a70ebdf253.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '0b88857e4b8397b7d0e082cb40688578',
      'native_key' => 'mgr',
      'filename' => 'modContext/81db7e4a386ad768b50339718f40ed47.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'bcc5b176a18a6e336cda8f5027f9f0b2',
      'native_key' => 'bcc5b176a18a6e336cda8f5027f9f0b2',
      'filename' => 'xPDOFileVehicle/a8cb5b9e61a4e09eda36d495b9f7ea2a.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f1fdd14e4705620dcd61ca9422afc94b',
      'native_key' => 'f1fdd14e4705620dcd61ca9422afc94b',
      'filename' => 'xPDOFileVehicle/f91f55804e3cb8059f83d708ccfcdc4c.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c952ca5d9764eaceac48a9eecb1b299f',
      'native_key' => 'c952ca5d9764eaceac48a9eecb1b299f',
      'filename' => 'xPDOFileVehicle/3c80f3aa02e1ee62d58dd8ad68173000.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'da940ec9f9b0e6bc45faeb0825bcd9ed',
      'native_key' => 'da940ec9f9b0e6bc45faeb0825bcd9ed',
      'filename' => 'xPDOFileVehicle/606afec215ca2e2efed26378ca78cc51.vehicle',
    ),
  ),
);