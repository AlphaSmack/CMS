--------------------
Snippet: getPage
--------------------
Version: 1.2.3-pl
Released: June 20, 2012
Since: March 19, 2010
Author: Jason Coward <jason@modx.com>

A generic wrapper snippet for returning paged results and navigation from snippets that return limitable collections. This release requires MODX Revolution 2.1+.

Official Documentation:
http://rtfm.modx.com/display/ADDON/getPage